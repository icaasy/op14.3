//
// Created by Anton on 30.01.2024.
//

#ifndef COURSE_ALGORITHM_H
#define COURSE_ALGORITHM_H

#endif //COURSE_ALGORITHM_H
